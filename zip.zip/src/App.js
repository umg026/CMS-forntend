import React from "react";
import Routess from "./Routes/Routes";

function App() {
  return (
    <div>
      <Routess/>
    </div>
  );
}

export default App;
